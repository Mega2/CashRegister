function dispHeader() {
	var acctbalbox = document.getElementById("acctbalbox");
	var acctavailbox = document.getElementById("acctavailbox");
	
	acctbalbox = account.currentBalance;
	acctavailbox = account.availableBalance;
}